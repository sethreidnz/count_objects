from distutils.core import setup

setup(
    name='countObjects',
    version='0.0.1',
    author='Seth Reid',
    author_email = 'contact@sethreid.co.nz',
    packages=['countObjects'],
    url='',
    license='LICENCE.txt',
    description = 'Package for analysing images for objects of interest',
    long_description=open('README.txt').read(),
    install_requires=[],
    )
