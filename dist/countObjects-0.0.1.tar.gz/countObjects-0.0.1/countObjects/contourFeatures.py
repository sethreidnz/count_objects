#This class used to initiat a contour object with functions to find
#specific features about a contour without pre-calculating them
import cv2
import numpy as np
import collections
import math

class Contour:
    
        def __init__(self,img,cnt):

                self.img = img
                self.cnt = cnt
                self.size = len(cnt)

        #get contour area
        def getArea(self):
                   
            self.area = cv2.contourArea(self.cnt)
  
            return self.area
            

        #get average position (centroid) of the contour relative to top left 0px,0px
        def getCentroid(self):
                
            self.moments = cv2.moments(self.cnt)
            if self.moments['m00'] != 0.0:       
                self.cx = self.moments['m10']/self.moments['m00']
                self.cy = self.moments['m01']/self.moments['m00']
                self.centroid = (int(round(self.cx,0)),int(round(self.cy)))
                return self.centroid            
            else:
                return "Region has zero area"

        def getBoundingBox(self):
                
                rect = cv2.minAreaRect(self.cnt)
                
                points = cv2.cv.BoxPoints(rect)
                points = np.int0(np.around(points))
                

                self.boundingBox_points = points
                self.boundingBox_top = points[0]
                self.boundingBox_right = points[1]
                self.boundingBox_bottom = points[2]
                self.boundingBox_right = points[3]
                
                return self.boundingBox_points

        def getBoundingEllipse(self):
                
                self.ellipse = cv2.fitEllipse(self.cnt)
                (self.ellipose_center,self.ellipse_axes,self.ellipse_orientation) = self.ellipse
                return self.ellipse
        
        def getMajorAxis(self):

                if (self.ellipse is None):
                        self.getBoundingEllipse()
                
                self.ellipse_MajorAxisLength = max(self.ellipse_axes)
                return self.ellipse_MajorAxisLength
                
        def getMinorAxis(self):

                if (self.ellipse is None):
                        self.getBoundingEllipse()
                
                self.ellispse_MinorAxisLength = min(self.ellipse_axes)  
                return self.ellispse_MinorAxisLength

        def getBoundingBoxDimensions(self):

                if (self.boundingBox_points is None):
                        self.getBoundingBox()

                #for dimention 1 using the top corner and the right corner
               
                a = (self.boundingBox_right[0] - self.boundingBox_top[0])            
                b = (self.boundingBox_right[1] - self.boundingBox_top[1])
                dimension1 = math.sqrt(a**2 + b**2)

                #for dimension 2 using the bottom corner and the left corner

                c = (self.boundingBox_right[0] - self.boundingBox_bottom[0])
                d = (self.boundingBox_right[1] - self.boundingBox_bottom[1])
                    
                                    
                dimension2 = math.sqrt(c**2 + d**2)

                width = round(min(dimension1,dimension2),2)
                height = round(max(dimension1, dimension2),2)
                return [width,height]
        def getContourLength(self):
                self.contourLength = cv2.arcLength(self.cnt,True)
                return self.contourLength
        
        def getCircularity(self):
                if (self.area is None):
                        self.getArea()
                if (self.contourLength is None):
                        self.ContourLength()
                               
                self.circularity = ((2*math.sqrt(math.pi*self.area)/self.contourLength))**2
                return self.circularity
