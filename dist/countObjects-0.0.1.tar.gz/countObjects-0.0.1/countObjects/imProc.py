import cv2
import sys

#attributes
thresholdValue = 90
lowThreshold = 90
max_lowThreshold = 100
ratio = 3
kernel_size = 3

#function definitions

def show_image(windowName,img):
    if (img == None):                      ## Check for invalid input
        print "Could not open or find the image"
    else:
        cv2.namedWindow(windowName, 0)        ## create window for display
        cv.ResizeWindow(windowName, 500,500);
        cv2.imshow(windowName,img)         ## Show image in the window
       
def close_image(img,elegment,iterations):
    if (img == None or element == None):## Check for invalid input
        print "Could not open or find the image"
    else:
        img = cv2.dilate(img, element, iterations=(iterations+1))
        img = cv2.erode(img, element, iterations=iterations)
      
        return img

def open_image(img,element,iterations):
    if (img == None or element == None):## Check for invalid input
        print "Could not open or find the image"
    else:
        img = cv2.dilate(img, element, iterations=(iterations+1))
        img = cv2.erode(img, element, iterations=iterations)

def threshold_image(img,thresholdValue):
    ret, threshold_image = cv2.threshold(gray_imageimg,thresholdValue,255,cv2.THRESH_BINARY_INV)
    return threshold_image
